var a=25;
var b=7;


var total=a%b;


console.log(total);