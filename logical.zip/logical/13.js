var a=2000;
var b=3;
var c=4;


var total=a*b*c/100;

console.log(total);