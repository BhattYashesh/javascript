var bill=60;
var tip;;


var tip=60*10/100;


var tbill=bill+tip;


console.log(tbill);
