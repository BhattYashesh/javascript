var a=4;
var b=3;
var c=5;



var total=a*b*c;

console.log(total);