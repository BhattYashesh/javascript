var hs=15;
var week =40;


var total=hs*week;

console.log(total);