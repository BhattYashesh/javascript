var wage=40;
var work=2400;

var total=wage*work;
console.log(total);