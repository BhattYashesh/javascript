var value=1000;
var intr=5;
var year=2;


var total=1000*5*2/100;
console.log(total);
