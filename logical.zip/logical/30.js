var bill=500;
var tax;

var tax=500*12/100;
console.log(tax);

var tip=560*18/100;
console.log(tip);
