var money=5000;
var rate=6;
var time=3;



var total=5000*6*3/100;

console.log(total);