var bill=40;
var tip;


var tip=40*15/100;

var tbill=bill+tip;
console.log(tbill);
