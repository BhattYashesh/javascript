var a=5;
var b=7;

console.log(a+b);