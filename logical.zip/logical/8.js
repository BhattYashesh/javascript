var a=25;
var b=160;


var total=a*b;

console.log(total);