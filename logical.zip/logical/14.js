var a=10;
var b=20;
var c=30;


var total=a+b+c;;

console.log(total);