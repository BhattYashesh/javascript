var a=20;
var b=5;

var total=a/b;


console.log(total);