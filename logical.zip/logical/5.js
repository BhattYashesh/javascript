var a=8;
var b= 4;


var total=a*b;

console.log(total);
