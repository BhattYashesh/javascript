var bill=100;
var tax;


var tax=100*20/100;

var total=bill+tax;


var tip=total*10/100;


var tbill=total+tip;
console.log(tbill);

