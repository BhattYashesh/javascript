var a=15;
var b=8;

var total=a-b;


console.log("the differenceis :"+total);