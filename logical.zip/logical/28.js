var money=4500;
var rate=6;
var year=7;


var total=money*rate*year/100;


console.log(total);