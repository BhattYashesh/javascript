var tm=30;
var th=2000;



var total=tm*th;


console.log(total);