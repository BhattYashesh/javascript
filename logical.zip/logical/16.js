var money=7000;
var rate=5;
var time=2;


var total=money*rate*time/100;

console.log(total);