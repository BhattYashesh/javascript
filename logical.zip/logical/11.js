var a=15;
var b=3;


var total=a*b;


console.log(total);