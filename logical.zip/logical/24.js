var money=2500;
var rate=4;
var year=5;


var total=money*rate*year/100;

console.log(total);