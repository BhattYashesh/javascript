var bill=80;
var text;


var text=80*12/100;

var tbill=bill+text;

console.log(tbill);
