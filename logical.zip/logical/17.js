var th=180;
var tm=18;


var total=th*tm;

console.log(total);
