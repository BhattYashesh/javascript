var  money=5000;
var rate=3.5;
var  year =10;


var total=money*rate*year/100;

console.log(total);
