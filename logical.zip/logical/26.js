var bill=200;
var tax;

var tax=200*25/100;

var total=bill+tax;


var tip=200*15/100;


var tbill=total+tip+20;
console.log(tbill);