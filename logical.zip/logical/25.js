var amount=150;
var tax;

var tax=150*15/100;


var total=amount+tax+10;
console.log(total);