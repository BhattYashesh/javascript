var a=50;
var text;

var text=50*8/100;

var total=text+a;

console.log(total);