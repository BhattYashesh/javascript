var bill=300;
var tax=10;

var tax=300*10/100;

var total=tax+bill+15;


console.log(total);
var dis=total-50;

console.log(dis);