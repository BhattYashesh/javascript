var bill=90;
var tax;

var tax=90*7/100;


var total=bill+tax;


console.log(total);