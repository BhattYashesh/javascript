let a=true;
console.log(typeof(a));