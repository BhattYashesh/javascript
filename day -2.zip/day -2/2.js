var a="Alice";
console.log(a);
var a="Bob";
console.log(a);