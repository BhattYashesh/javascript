const pi=3.14;
console.log(pi);
const pi=3.1415;
console.log(pi);