var x=10;
console.log(x);
var y=20;
console.log(y);
var z=x+y;
console.log(z);
    