let a=null;
console.log(a);