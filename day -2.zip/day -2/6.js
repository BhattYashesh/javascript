let age;
console.log(age);