let a=1;
let num=100;
let sum=0;

for(a=1;a<=100;a++)
    {
        sum+=a;
           if(sum>=1000)
            {
               
                break;
            }
            console.log(sum);
            a++
             
            
             
    }