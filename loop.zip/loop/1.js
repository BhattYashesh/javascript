let a=1;

for(a=1;a<=10;a++)
    {
        if(a%2==0)
            {
                continue;
            }
            console.log(a);
            a++
    }