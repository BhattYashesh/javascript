let a;
let number=5;
let result;
for(a=1;a<=10;a++)
    {
        let result=number*a;
        if(a%2==0)
            {
                continue;
            }
          
          console.log(result);
          a++
            
           
    }