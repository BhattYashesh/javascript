var year=2024;

console.log(year%4==0)
