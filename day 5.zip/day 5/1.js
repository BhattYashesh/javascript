var x=5;
var y=10;

x=x+y;
y=x-y;
x=x-y;

console.log("x after swap " + x );
console.log("y after swap " + y );