var a=29;
var b=6;

var c=a%b;
console.log(c);