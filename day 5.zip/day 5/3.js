var a=3;
var b=4;
var c=5;

var d=(a*a)+(b*b)+(c*c);
console.log(d);