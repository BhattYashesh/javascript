var basic=20000;
var allowance=2000;
var total=basic+allowance;
console.log(total);