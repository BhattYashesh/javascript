var x=10;
var y=20;
var z;

console.log("Before swapping x "+ x);
console.log("Before swapping y "+y);

z=x;
x=y;
y=z;

console.log("After swapping x "+ x);
console.log("After swapping y "+y);