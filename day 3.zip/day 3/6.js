var amt=500;
var tax=amt*10/100;
var final=amt+tax;
console.log(final);