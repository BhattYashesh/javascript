var rate=200;
var qty=100;
var years=2;
var int=rate*qty*years;
console.log(int);