var radius=360;
var perimeter=2*3.14*radius;
console.log(perimeter);