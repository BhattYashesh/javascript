var length=200;
 var width=150;
var rec=length*width;
console.log(rec);