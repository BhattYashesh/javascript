var height=500;
var base=100;
var triangle=1/2*height*base;
console.log(triangle);