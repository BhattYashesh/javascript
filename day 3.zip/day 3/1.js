var r=360;
var a=3.14*r*r;
console.log(a);