let a=1;

while(a<=20)
    {
        if(a%2==0)
            {
                console.log(a)
            }
        
        a++;
    }