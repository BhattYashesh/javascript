let a=1;
while(a<=5)
    {
        console.log(a*a);
        a++;
    }