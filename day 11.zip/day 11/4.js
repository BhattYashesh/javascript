let a=2;
let start = 1;
let limit = 6;
let digit = 1;

while(start<=limit)
{
    digit *= a;
    start++;
    console.log(digit +" ");
}
