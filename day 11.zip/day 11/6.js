let a=1;
let fac=1;

while(a<=10)
    {
        
        fac=fac*a;
        
        a++
    }
    console.log(fac);