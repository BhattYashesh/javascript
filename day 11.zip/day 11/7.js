let a=1;
let sum=0;
while(a<=10)
    {
       sum=sum+a;
       
       a++;
    }
    console.log(sum);