let a=10;

while(a>=1)
    {
        console.log(a);
        a--;
    }